﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Script.Serialization;

namespace JQUERY_Learn
{
    /// <summary>
    /// Summary description for RegisterationService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
     [System.Web.Script.Services.ScriptService]
    public class RegisterationService : System.Web.Services.WebService
    {
        
 
        public  bool UserNameExists(string userName)
        {
            
            string cs = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("spUserNameExists", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter()
                {

                    ParameterName = "@UserName",
                    Value = userName


                });

                con.Open();
              return  Convert.ToBoolean(cmd.ExecuteScalar());
            }


            
        }


        [WebMethod]

        public  Registration GetAvailableUserName(string userName)
        {
            Registration registeration = new Registration();
            registeration.UserNameInUse = false;
            while(UserNameExists(userName))
            {
                Random random = new Random();
                int randomNumber = random.Next(1, 100);
                userName = userName + randomNumber.ToString();
                registeration.UserNameInUse = true;
            }
            registeration.UserName = userName;

           // JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();

             //Context.Response.Write(javaScriptSerializer.Serialize(registeration));


            return registeration;
        }
    }
}




           