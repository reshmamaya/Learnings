﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JQUERY_Learn
{
    public class Registration
    {
        public string UserName { get; set; }
        public bool UserNameInUse { get; set; }
    }
}